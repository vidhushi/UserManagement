import React, { Component } from 'react'
import { Header, Button, Form, Grid,  Segment } from 'semantic-ui-react';
import header from '../Beautification/Beautification.css';
import between from '../Beautification/Beautification.css';
import between2 from '../Beautification/Beautification.css';


class Insert extends Component {
constructor () 
{
    super();
    this.state = {
            newuser: '',
             id : '',
            first_name : '',
            last_name : '',
            Email : '',
            IsStatus : '',
            UserType : '' 
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
    
  }


   

 
handleSubmit (){

  let user = {
    id : this.state.id,
    first_name : this.state.first_name,
    last_name : this.state.last_name,
    Email : this.state.Email,
    IsStatus : this.state.IsStatus,
    UserType : this.state.UserType
  }

  
  console.log(JSON.stringify(user));

  console.log(this.state)
    
  fetch('http://localhost:3000/InsertUserData', {
  method: 'POST', 
  body: JSON.stringify(user),
  headers:{
    'Content-Type': 'application/json',
  }
})
.then( res => res.json())
.then( data=>{
      console.log(data);
      this.props.click();
    })
    
}

handleChange (evt)
 {
    this.setState({ [evt.target.name]: evt.target.value });
 }

    render() {
        return (
            <div>
            <div className="header">
            <Header></Header>
            <h2>To Insert User please enter the following details</h2>
            </div>
            <div className="between"></div>
            <div className="between2"></div>
  
            <Grid textAlign='center' style={{ height: '100%' }} verticalAlign='middle'>
             <Grid.Column style={{ maxWidth: 450 }}>
            <Form size='large'>
            <Segment stacked>

           <div>Id of User: <input type = "text" name = "id" onChange={this.handleChange} value={this.state.id}  /> </div>      
           <div>First name: <input type = "text" name = "first_name" onChange={this.handleChange} value={this.state.first_name} /></div>
           <div>Last name: <input type = "text" name = "last_name" onChange={this.handleChange} value={this.state.last_name} /></div>
           <div>Email: <input type = "text" name = "Email" onChange={this.handleChange} value={this.state.Email} /></div>
           <div> Status:<input type = "text" name = "IsStatus" onChange={this.handleChange} value={this.state.IsStatus}/></div>
           <div>Type<input type = "text" name = "UserType" onChange={this.handleChange} value={this.state.UserType} /></div>
           
          <Button onClick={this.handleSubmit}>Insert user</Button>


          </Segment>
        </Form>
        </Grid.Column>
         </Grid>
          
          
            </div>
        );
      }

}

export default Insert;