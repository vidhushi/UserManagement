import React, { Component } from 'react'
//import { Header, Button } from 'semantic-ui-react';
import loginheader from '../Beautification/Beautification.css';
import between from '../Beautification/Beautification.css';
import { Form, Grid, Header, Segment } from 'semantic-ui-react'
import between2 from '../Beautification/Beautification.css';

class Login extends Component {
    render() {
        return (
            <div>
            <div className="loginheader">
            <Header></Header>
            <h2>Welcome To User Management</h2>
            </div>
            <div className="between"></div>
            <div className="between2"></div>
            <Grid textAlign='center' style={{ height: '100%' }} verticalAlign='middle'>
             <Grid.Column style={{ maxWidth: 450 }}>
            <Form size='large'>
            <Segment stacked>
            <Form.Input fluid icon='user' iconPosition='left' placeholder='E-mail address' />
            <Form.Input
              fluid
              icon='lock'
              iconPosition='left'
              placeholder='Password'
              type='password'
            />
          </Segment>
        </Form>
        </Grid.Column>
         </Grid>
            </div>
        );
      }

}

export default Login;