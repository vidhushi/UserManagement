import React, { Component } from 'react';
import './App.css';
 import { Button } from 'semantic-ui-react';

import  Insert from './components/Insert/Insert'
import  Login from './components/Login/Login'
import backgoundcolor from './components/Beautification/Beautification.css';
import Update from './components/Update/Update';
import Delete from './components/Delete/Delete';

// import  Read from './components/Read/Read.js'

class App extends Component {

  constructor(props){
    super(props);
    
    this.state ={
      Users: [],
      Currentwindow:'Login'
    }

     this.handlechange = this.handlechange.bind(this)
     this.insertuser = this.insertuser.bind(this)
     this.backtoread = this.backtoread.bind(this)
     this.gotoupdate = this.gotoupdate.bind(this)
     this.gotodelete = this.gotodelete.bind(this)
     this.deleteUser = this.deleteUser.bind(this)
     
  }




  
  componentDidMount(){
    /*fetch('http://localhost:3000/GetUserData')
      .then( res=>res.json() )
      .then( data=>{
        console.log(data);
        this.setState({
          Users : data.recordset
        })
        console.log(this.state.Users);
      })*/
      
  }




   handlechange = (Currentwindow) =>
   {
     this.setState({Currentwindow: 'Read'});

     fetch('http://localhost:3000/GetUserData')
         .then( res=>res.json() )
           .then( data=>{
        console.log(data);
        this.setState({
          Users : data.recordset
        })
        console.log(this.state.Users);
      })
   }
    
  insertuser = (Currentwindow) =>{
     this.setState({Currentwindow: 'Insert'});
                                   }   
                                   
                                   
  backtoread = (Currentwindow) =>{
    this.setState({Currentwindow: 'Read'});
      this.handlechange();

  }


  gotoupdate = (Currentwindow) =>{
    this.setState({Currentwindow: 'Update'});
  }

  deleteUser = (id) =>{
    let data ={
      id : id        
    }
      fetch('http://localhost:3000/deleteUserData', {
        method: 'POST', 
        body: JSON.stringify(data),
        headers:{
          'Content-Type': 'application/json',
        }
      })
      .then( res=>res.json() )
      .then( data=>{
        this.backtoread()
          console.log(data);
      })
    }

  gotodelete = (id) =>{
    
    var txt;
    if (window.confirm("Do you want to delete this record")) {
         this.deleteUser(id);
    } else {
      console.log(txt = "You pressed Cancel!");
    }
  }




  render() {
    const {Users} = this.state;
    console.log(Users);
    let window=null; 

    if(this.state.Currentwindow === 'Login') 
    window = (<div>
       <Login />
       <div className="backgoundcolor">
       <Button color='teal' onClick={(e) => { this.handlechange();}}>
              Login
            </Button>
            </div>
      </div>)


    else if(this.state.Currentwindow === 'Read') 
    window = (<div>
      
    <table className="ui celled table">
    <thead>
      <tr>
        <th>User ID</th>
        <th>User First-Name</th>
        <th>User Last-Name</th>
        <th>User Email</th>
        <th>User Status</th>
        <th>User Type</th>
        <th>Delete</th>
        <th>Update</th>
        <th>
        <Button onClick={this.insertuser}>Insert user</Button>
        </th>
      </tr>
    </thead>
    {<tbody>
     {
      this.state.Users.map((user, i ) => {
        return (
          <tr key={user.id}>
            <td>{user.id}</td>
            <td>{user.first_name}</td>
            <td>{user.last_name}</td>
            <td>{user.Email}</td>
            <td>{user.IsStatus}</td>
            <td>{user.UserType}</td>
            <td><Button onClick={()=>this.gotodelete(user.id)}>Delete</Button></td>
            <td><Button onClick={this.gotoupdate}>Update</Button></td>
          </tr>
        )
      })
    }
     </tbody>}
    </table> 
    </div>)

    else if(this.state.Currentwindow === 'Insert')
    {
      window = <div>
      <Insert click={this.backtoread} />
      </div>
    }

    else if(this.state.Currentwindow === 'Update')
    {
      window = <div>
         <Update click={this.backtoread} />
        </div>
    }

    else if(this.state.Currentwindow === 'Delete')
    {
      window = <div>
         <Delete/>
        </div>
    }




    return (
        window
            );
  }
}

export default App;
